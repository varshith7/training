package com.dbs.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
