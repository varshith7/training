package com.dbs.spring.respository;

import org.springframework.data.repository.CrudRepository;

import com.dbs.spring.model.Transfertypes;

public interface TransfertypesRepository  extends CrudRepository<Transfertypes , String>{

}
