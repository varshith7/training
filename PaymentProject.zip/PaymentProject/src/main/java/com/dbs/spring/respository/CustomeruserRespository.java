package com.dbs.spring.respository;

import org.springframework.data.repository.CrudRepository;

import com.dbs.spring.model.Customeruser;
public interface CustomeruserRespository extends CrudRepository<Customeruser,Integer>{

}
