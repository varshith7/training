package com.dbs.spring.constants;

public class Constants {
	public final static String CUSTOMER_TRANSFER_TYPE = "C",BANK_OWN_TRANSFER_TYPE = "O";
	public static final String OWN_BANK = "HDFC BANK";
	public static final Double TRANSFER_FEE_RATE = 0.25;
}