package com.dbs.spring.capstoneproject.repository;

import org.springframework.data.repository.CrudRepository;

import com.dbs.spring.capstoneproject.model.Instruments;

public interface InstrumentsRepository extends CrudRepository<Instruments,String> {


}
