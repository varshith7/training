package com.dbs.spring.capstoneproject.repository;

import org.springframework.data.repository.CrudRepository;

import com.dbs.spring.capstoneproject.model.Custodian;

public interface CustodianRepository extends CrudRepository<Custodian,String> {
	
	

}
